# Changelog
    
    1.0.6
    # Fixed WK2 css animation on mobiles

    1.0.5
    # Removed duplicate debug from footer
    # Fixed document height for uk-modal component

    1.0.4
	^ Updated UIkit theme according to UIkit 2.20.0
	# Fixed Article Navigation (J)

    1.0.3
    + Added WooCommerce products per page option (WP)

    1.0.2
    ^ Updated UIkit theme according to UIkit 2.17.0

    1.0.1
    ^ Updated UIkit theme according to UIkit 2.15.0

    1.0.0
    + Initial Release



    * -> Security Fix
    # -> Bug Fix
    $ -> Language fix or change
    + -> Addition
    ^ -> Change
    - -> Removed
    ! -> Note
